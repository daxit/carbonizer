var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/carbonizer.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/carbonizer.js":
/*!***************************!*\
  !*** ./src/carbonizer.js ***!
  \***************************/
/*! exports provided: carbonizeAllPages, carbonizePage, carbonizeArtboard, carbonizeLayer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "carbonizeAllPages", function() { return carbonizeAllPages; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "carbonizePage", function() { return carbonizePage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "carbonizeArtboard", function() { return carbonizeArtboard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "carbonizeLayer", function() { return carbonizeLayer; });
var sketch = __webpack_require__(/*! sketch */ "sketch"); // documentation: https://developer.sketchapp.com/reference/api/


var document = sketch.getSelectedDocument(); // Regular expressions used to find and replace layer names

var EXPRESSION_PATH_COMPONENT = /^utilities \/ spacer \/ component \/ .+? \/ (.+?) \/ .+/;
var EXPRESSION_PATH_LAYOUT = /^utilities \/ spacer \/ layout \/ (.+?) /;
var EXPRESSION_PATH_PB = /^(layout|spacing) \/ redline \/ (horizontal|vertical) \/ /;
var EXPRESSION_RENAME = /(spacing|layout)-../;
var EXPRESSION_TEMPLATE = /Layout grid [0-1][0-9]?/;
var TEMPLATE_LAYERS = ['Layout grid', 'outside-margin', 'outside-margin-left', 'outside-margin-right'];
var WARNING_TITLE = 'WARNING';
var WARNING_MESSAGE = 'This action is not reversible after you quit Sketch. After this runs, UNDO (Cmd + Z) and make a copy if you forgot!';

function carbonizeAllPages() {
  sketch.UI.alert(WARNING_TITLE, WARNING_MESSAGE);
  var log = [];
  document.pages.forEach(function (page) {
    log.push(page.name);
    page.layers.forEach(function (layer) {
      log = log.concat(processLayer(layer));
    });
    sketch.UI.message("Finished Carbonizing ".concat(log.length, " layers in ").concat(pages.length, " pages"));
  });
  console.log(log);
}

function carbonizePage() {
  sketch.UI.alert(WARNING_TITLE, WARNING_MESSAGE);
  var log = [];
  document.selectedPage.layers.forEach(function (layer) {
    log = log.concat(processLayer(layer));
  });
  console.log(log);
  sketch.UI.message("Finished Carbonizing ".concat(log.length, " layers in ").concat(document.selectedPage.name));
}

function carbonizeArtboard() {
  sketch.UI.alert(WARNING_TITLE, WARNING_MESSAGE);

  if (document.selectedLayers.length === 1 && document.selectedLayers.layers[0].type === 'Artboard') {
    var log = processLayer(document.selectedLayers.layers[0]);
    console.log(log);
    sketch.UI.message("Finished Carbonizing ".concat(log.length, " layers in ").concat(document.selectedLayers.layers[0].name));
  } else {
    sketch.UI.message('No Artboard selected');
  }
}

function carbonizeLayer() {
  sketch.UI.alert(WARNING_TITLE, WARNING_MESSAGE);

  if (document.selectedLayers.length === 1) {
    var log = processLayer(document.selectedLayers.layers[0]);
    console.log(log);
    sketch.UI.message("Finished Carbonizing ".concat(log.length, " layers in ").concat(document.selectedLayers.layers[0].name));
  } else {
    sketch.UI.message('No Layer selected');
  }
}

function processLayer(layer) {
  var log = [];
  log = _processLayer(layer, log);
  return log;
}

function _processLayer(layer, log) {
  if (TEMPLATE_LAYERS.includes(layer.name.trim()) || EXPRESSION_TEMPLATE.test(layer.name.trim())) {
    layer.locked = true;
    return log;
  }

  layer.locked = false;

  var isValid = function isValid(layer) {
    var isValid = false;
    isValid = isValid || EXPRESSION_PATH_COMPONENT.test(layer.master.name);
    isValid = isValid || EXPRESSION_PATH_LAYOUT.test(layer.master.name);
    isValid = isValid || EXPRESSION_PATH_PB.test(layer.master.name);
    return isValid;
  };

  switch (layer.type) {
    case 'SymbolInstance':
      {
        if (isValid(layer)) log.push(detachRenameSymbol(layer, EXPRESSION_RENAME));else log.push("[".concat(layer.type, "] ").concat(layer.name, ": Symbol does not match regular expression"));
        break;
      }

    case 'Text':
    case 'Shape':
    case 'ShapePath':
      {
        if (layer.sharedStyle === null) {
          log.push("[".concat(layer.type, "] ").concat(layer.name, ": Layer has no style applied"));
          break;
        }

        var oldName = layer.name;
        layer.name = layer.sharedStyle.name;
        log.push("[".concat(layer.type, "] ").concat(oldName, ": Successfully renamed to ").concat(layer.name));
        break;
      }

    case 'Group':
    case 'Artboard':
      layer.layers.forEach(function (child) {
        return _processLayer(child, log);
      });
      break;

    default:
      log.push("[".concat(layer.type, "] ").concat(layer.name, ": Layer is not an accepted type"));
  }

  return log;
}
/**
 * Detach the given SymbolInstance layer into a group and rename it based on the provided
 * regular expression. The regular expression is used to match a substring in the name of
 * the SymbolInstance's master.
 *
 * @param {*} layer the SymbolInstance to rename
 * @param {*} renameExpression the regular expression to rename the layer
 */


function detachRenameSymbol(layer, renameExpression) {
  var oldName = layer.name;
  var name = layer.master.name.match(renameExpression)[0];
  var group = layer.detach(); // detach the symbol into a group

  group.name = name; // rename the group to a substring of the original style's name

  group.layers.forEach(function (childLayer) {
    childLayer.name = group.name; // rename the children layers to their group's name

    childLayer.locked = false; // make sure to unlock the children
  });
  return "[".concat(layer.type, "] ").concat(oldName, ": Successfully renamed to ").concat(layer.name);
} // This function is unused future functionality to
// save the sketch file before renaming the layers in it


function saveDocument(document) {
  document.save('~/Desktop/Carbonizer Temp.sketch', {
    saveMode: sketch.Document.SaveMode.SaveAs
  }, function (err) {
    if (err) sketch.UI.alert('Error', 'Doc save failed');
    console.log(err);
  });
}



/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['carbonizeAllPages'] = __skpm_run.bind(this, 'carbonizeAllPages');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['carbonizePage'] = __skpm_run.bind(this, 'carbonizePage');
globalThis['carbonizeArtboard'] = __skpm_run.bind(this, 'carbonizeArtboard');
globalThis['carbonizeLayer'] = __skpm_run.bind(this, 'carbonizeLayer')

//# sourceMappingURL=__carbonizer.js.map